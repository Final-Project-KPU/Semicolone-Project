package org.safe.persistence;

import java.util.List;

import org.safe.domain.DistapVO;

public interface DistapDAO {
	public List<DistapVO> distapList() throws Exception;
}
