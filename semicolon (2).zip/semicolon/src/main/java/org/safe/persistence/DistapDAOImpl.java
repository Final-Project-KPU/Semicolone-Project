package org.safe.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.safe.domain.DistapVO;
import org.springframework.stereotype.Repository;

@Repository
public class DistapDAOImpl implements DistapDAO {
	
	@Inject
	private SqlSession session;
	
	private static String namespace = "org.safe.mapper.DistapMapper";
	
	@Override
	public List<DistapVO> distapList() throws Exception{
		// TODO Auto-generated method stub
		return session.selectList (namespace + ".distList");
	}
}
