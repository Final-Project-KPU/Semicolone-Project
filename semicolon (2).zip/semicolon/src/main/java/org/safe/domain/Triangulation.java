package org.safe.domain;

public class Triangulation {
	
	private int x,y; //현재 위치(x,y)
	
	
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public void calculate(int x1, int y1, int x2, int y2, int x3, int y3, int[] dis) {
		// TODO Auto-generated method stub
		int a= 2*(x1-x2);
		int b= 2*(y1-y2);
		int c= 2*(x1-x3);
		int d= 2*(y1-y3);
		double i= Math.pow(dis[1], 2) - Math.pow(dis[0], 2) - Math.pow(x2, 2) - Math.pow(y2, 2) + Math.pow(x1, 2) +Math.pow(y1, 2);
		double j= Math.pow(dis[2], 2) - Math.pow(dis[0], 2) - Math.pow(x3, 2) - Math.pow(y3, 2) + Math.pow(x1, 2) +Math.pow(y1, 2);
		System.out.println("a=" + a + " b=" + b + " c=" +c +" d=" +d +" i=" + i + " j=" + j);
		simultaneous(a,b,c,d,i,j);
		
		System.out.println("x=" + this.x + " y=" + this.y );
	}
	
	public void simultaneous(double a, double b, double c, double d, double i, double j) {
		// TODO Auto-generated method stub
		double deno = (a*d) - (b*c); //역행렬구할때 ad-bc=0 인지 아닌지 조건 확인위한 변수 
		System.out.println("deno = " +deno);
		System.out.println("분자x =" + ((d*i)-(b*j)));
		System.out.println("분자y =" + (-(c*i)+(a*j)));
		if(deno!=0){
		this.x= (int) (((d*i)-(b*j))/deno);
		this.y= (int) ((-(c*i)+(a*j))/deno);
		}else{
			this.x=0;
			this.y=0;
		}
	}

}
