package org.safe.domain;

public class Friis{
	static final double pi = Math.PI;
	
	private double c = 0; //전파속도
	private double f = 0; //주파수
	private double L = 0; //전송손실(RSSI)
	private double d = 0; //현재 위치와 AP 두점사이의 거리
	
	
	public void setC(double c) {
		this.c = c;
	}

	public void setF(double f) {
		this.f = f;
	}

	public void setL(double l) {
		L = l;
	}

	public double getD() {
		return d;
	}

	public double calculate(double c, double f, double L) {
		// TODO Auto-generated method stub
		this.c=c;
		this.f=f;
		this.L=L;
		
		this.d= this.c/(4 * pi * this.f)*Math.pow(10, this.L/20);
		
		return d;
	}

}
