package org.safe.controller;

import java.text.DateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

import javax.inject.Inject;

import org.safe.domain.PositVO;
import org.safe.service.PositService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	@Inject
	PositService Pservice;
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	@RequestMapping("/draw")
	public String draw(Model model) throws Exception{
		LocalDateTime now = LocalDateTime.now(); //현재시간
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm"); //시간 형식 설정
        String formatDateTime = now.format(formatter);
		model.addAttribute("formatDateTime", formatDateTime );
		
		PositVO vo = Pservice.inquire();
		model.addAttribute("x", (int)vo.getX());
		model.addAttribute("y", (int)vo.getY());
		
		String local = "";
		if(vo.isSign()) {
			local = "위험";
		}else {
			local="안전";
		}
		model.addAttribute("local", local);
		return "view";
	}
	
}
