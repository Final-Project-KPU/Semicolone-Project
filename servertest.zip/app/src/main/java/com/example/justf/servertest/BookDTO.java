package com.example.justf.servertest;

/**
 * Created by justf on 2018-05-17.
 */

public class BookDTO {
    private int book_code;
    private String book_name;
    private String press;
    private int price;
    private int amount;
    // getter setter

    public int getBook_code() {
        return book_code;
    }

    public String getBook_name() {
        return book_name;
    }

    public String getPress() {
        return press;
    }

    public int getPrice() {
        return price;
    }

    public int getAmount() {
        return amount;
    }

    public void setBook_code(int book_code) {
        this.book_code = book_code;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    public void setPress(String press) {
        this.press = press;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "BookDTO{" +
                "book_code=" + book_code +
                ", book_name='" + book_name + '\'' +
                ", press='" + press + '\'' +
                ", price=" + price +
                ", amount=" + amount +
                '}';
    }
}

