package org.safe.persistence;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.safe.domain.PositVO;
import org.springframework.stereotype.Repository;

@Repository
public class PositDAOImpl implements PositDAO {
	
	@Inject
	private SqlSession session;
	
	private static String namespace = "org.safe.mapper.PositMapper";
	@Override
	public void insert(PositVO vo) throws Exception {
		// TODO Auto-generated method stub
		session.insert(namespace+".positInsert", vo);
			
	}
	
	@Override
	public PositVO inquire() throws Exception{
		PositVO vo = null;
		vo =session.selectOne(namespace+".selectNowPosit");
		return vo;
	}
}

