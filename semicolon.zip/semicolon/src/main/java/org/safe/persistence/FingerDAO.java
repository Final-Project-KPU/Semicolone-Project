package org.safe.persistence;

import java.util.List;

import org.safe.domain.FingerVO;

public interface FingerDAO {
	public List<FingerVO> fingerList() throws Exception;
}
