package org.safe.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.safe.domain.Criteria;
import org.safe.domain.DistapVO;
import org.springframework.stereotype.Repository;

@Repository
public class DistapDAOImpl implements DistapDAO {
	
	@Inject
	private SqlSession session;
	
	private static String namespace = "org.safe.mapper.DistapMapper";
	
	@Override
	public List<DistapVO> distapList(int band_id) throws Exception{
		// TODO Auto-generated method stub
		return session.selectList (namespace + ".distList", band_id);
	}
	
	@Override
	public Criteria getCriteria() throws Exception{
		return session.selectOne(namespace + ".criteria");
	}
}
