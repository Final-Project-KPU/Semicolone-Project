package org.safe.persistence;

import java.util.List;

import org.safe.domain.Criteria;
import org.safe.domain.DistapVO;

public interface DistapDAO {
	public List<DistapVO> distapList(int band_id) throws Exception;
	public Criteria getCriteria() throws Exception;
}
