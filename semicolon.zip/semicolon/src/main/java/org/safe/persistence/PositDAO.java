package org.safe.persistence;

import org.safe.domain.PositVO;

public interface PositDAO {

	public void insert(PositVO vo)throws Exception;
	
	public PositVO inquire()throws Exception;
}
