package org.safe.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.safe.domain.FingerVO;
import org.springframework.stereotype.Repository;

@Repository
public class FingerDAOImpl implements FingerDAO {
	
	@Inject
	private SqlSession session;
	
	private static String namespace = "org.safe.mapper.Rssi2Mapper";
	
	@Override
	public List<FingerVO> fingerList() throws Exception{
		// TODO Auto-generated method stub
		return session.selectList (namespace + ".fingerList");
	}
}
