package org.safe.domain;

import java.sql.Date;

public class DistapVO {
    private String id;
    private Date regrate;
    private int x;
    private int y;
    private int dist;

    
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Date getRegrate() {
		return regrate;
	}
	public void setRegrate(Date regrate) {
		this.regrate = regrate;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getDist() {
		return dist;
	}
	public void setDist(int dist) {
		this.dist = dist;
	}
	
	
}