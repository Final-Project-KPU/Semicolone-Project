package org.safe.domain;

import java.sql.Date;

public class DistapVO {
	private int band_id;
    private int id;
    private Date regdate;
    private int x;
    private int y;
    private int dist;

    
	
	public int getBand_id() {
		return band_id;
	}
	public void setBand_id(int band_id) {
		this.band_id = band_id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegrate(Date regdate) {
		this.regdate = regdate;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getDist() {
		return dist;
	}
	public void setDist(int dist) {
		this.dist = dist;
	}
	
	
}