package org.safe.domain;

import java.sql.Date;

/*
 * 
 * */

public class RssiVO {
	String band_id;
	Date time;
	int ap1_rssi;
	int ap2_rssi;
	int ap3_rssi;
	int ap4_rssi;
	
	
	public String getBand_id() {
		return band_id;
	}
	public void setBand_id(String band_id) {
		this.band_id = band_id;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public int getAp1_rssi() {
		return ap1_rssi;
	}
	public void setAp1_rssi(int ap1_rssi) {
		this.ap1_rssi = ap1_rssi;
	}
	public int getAp2_rssi() {
		return ap2_rssi;
	}
	public void setAp2_rssi(int ap2_rssi) {
		this.ap2_rssi = ap2_rssi;
	}
	public int getAp3_rssi() {
		return ap3_rssi;
	}
	public void setAp3_rssi(int ap3_rssi) {
		this.ap3_rssi = ap3_rssi;
	}
	public int getAp4_rssi() {
		return ap4_rssi;
	}
	public void setAp4_rssi(int ap4_rssi) {
		this.ap4_rssi = ap4_rssi;
	}
	
}
