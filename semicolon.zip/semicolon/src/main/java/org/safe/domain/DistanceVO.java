package org.safe.domain;

public class DistanceVO {
	String between_num;
	String ap_name1;
	String ap_name2;
	String rssi;
	
	public String getBetween_num() {
		return between_num;
	}
	public void setBetween_num(String between_num) {
		this.between_num = between_num;
	}
	public String getAp_name1() {
		return ap_name1;
	}
	public void setAp_name1(String ap_name1) {
		this.ap_name1 = ap_name1;
	}
	public String getAp_name2() {
		return ap_name2;
	}
	public void setAp_name2(String ap_name2) {
		this.ap_name2 = ap_name2;
	}
	public String getRssi() {
		return rssi;
	}
	public void setRssi(String rssi) {
		this.rssi = rssi;
	}
}
