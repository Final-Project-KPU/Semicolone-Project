package org.safe.domain;

import java.sql.Date;

public class PositVO {
	private int band_id;
	private int x;
	private int y;
	private boolean sign;
	private Date regdate;
	
	public PositVO() {
		sign = false;
	}
	
	public Date getRegdate() {
		return regdate;
	}
	
	public int getBand_id() {
		return band_id;
	}

	public void setBand_id(int band_id) {
		this.band_id = band_id;
	}

	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public boolean isSign() {
		return sign;
	}
	public void setSign() {
		if(y>=6000)
			sign = true;
	}
	
}
