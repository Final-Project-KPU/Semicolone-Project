package org.safe.domain;

import java.sql.Date;

public class PositVO {
	Date time;
	int x;
	int y;
	boolean sign;
	
	public PositVO() {
		sign = false;
	}
	
	public Date getTime() {
		return time;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public boolean isSign() {
		return sign;
	}
	public void setSign() {
		if(y>=4000)
			sign = true;
	}
	
}
