package org.safe.controller;

import javax.inject.Inject;

import org.safe.domain.PositVO;
import org.safe.service.PositService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Handles requests for the application home page.
 */
@Controller
public class ResponseController {
private static final Logger logger = LoggerFactory.getLogger(ResponseController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@Inject
	PositService Pservice;
	
	@RequestMapping(value = "/doJSON", method = RequestMethod.GET)
	public @ResponseBody String doJSON() throws Exception {
		
		logger.info("Requested JSON");
		PositVO[] vl = new PositVO[2];
		vl[0] = Pservice.inquire(1);
		vl[1] = Pservice.inquire(2);
		//vl[2] = Pservice.inquire(3);
		String string = "";
		for(PositVO vo : vl) {
			if(vo.isSign()) {
				string += vo.getBand_id()+ " ";
			}
		}
		if(string.equals("")) {
			string = "0";
		}
		
		logger.info("Response JSON");
		
		return string;
	}
}
