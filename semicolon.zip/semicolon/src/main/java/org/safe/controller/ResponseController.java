package org.safe.controller;

import javax.inject.Inject;

import org.safe.domain.PositVO;
import org.safe.service.PositService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Handles requests for the application home page.
 */
@Controller
@RequestMapping("/posit")
public class ResponseController {
private static final Logger logger = LoggerFactory.getLogger(ResponseController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@Inject
	PositService Pservice;
	
	@RequestMapping(value = "/doJSON", method = RequestMethod.GET)
	public @ResponseBody PositVO doJSON() throws Exception {
		
		logger.info("Requested JSON");
		PositVO vo = Pservice.inquire();
				
		logger.info("Response JSON");
		return vo;
	}
}
