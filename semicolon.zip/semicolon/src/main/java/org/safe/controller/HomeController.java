package org.safe.controller;

import java.text.DateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.safe.domain.PositVO;
import org.safe.service.DistapService;
import org.safe.service.PositService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

/**
 * Handles requests for the application home page.
 */
@Controller
@SessionAttributes("criteria")
public class HomeController {
	
	@Inject
	DistapService Dservice;
	@Inject
	PositService Pservice;
	/**
	 * Simply selects the home view to render by returning its name.
	 * @throws Exception 
	 */
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model, HttpSession session) throws Exception {
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	@RequestMapping("/draw")
	public String draw(Model model) throws Exception{
		LocalDateTime now = LocalDateTime.now(); //현재시간
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH시 mm분"); //시간 형식 설정
        String formatDateTime = now.format(formatter);
		model.addAttribute("formatDateTime", formatDateTime );
		
		List<PositVO> vl = new ArrayList<>();
		vl.add(Pservice.inquire(1));
		vl.add(Pservice.inquire(2));
		vl.add(Pservice.inquire(3));
		
		model.addAttribute("criteria", Dservice.getCriteria());	
		model.addAttribute("v1", vl.get(0));
		model.addAttribute("v2", vl.get(1));
		model.addAttribute("v3", vl.get(2));
		
		
		return "view";
	}
	
}
