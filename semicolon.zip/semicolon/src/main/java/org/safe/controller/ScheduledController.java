package org.safe.controller;

import javax.inject.Inject;

import org.safe.domain.PositVO;
import org.safe.service.DistapService;
import org.safe.service.PositService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/sch")
public class ScheduledController {
	
	@Inject
	DistapService Dservice;
	
	@Inject
	PositService Pservice;
	
	private static final Logger logger = LoggerFactory.getLogger(ScheduledController.class);
	
	@Scheduled(fixedRate = 1000)
	@RequestMapping(value= "/get", method = RequestMethod.GET)
	public void distapList() throws Exception{
		logger.info("Get dist...........");
		posit(Dservice.distapList());
	}
	
	@RequestMapping(value= "/insert", method = RequestMethod.POST)
	public void posit(PositVO p) throws Exception{
		Pservice.insertPosit(p);
		logger.info("Insert posit...........");
		System.out.println("");
		System.out.println("-----------------------------------------------------------------------");
		System.out.println("");
	}
	
	@RequestMapping("/draw")
	public String draw(Model model) throws Exception{
		PositVO vo = Pservice.inquire();
		model.addAttribute("x", (double)vo.getX()/20);
		model.addAttribute("y", (double)vo.getY()/20);
		logger.info("draw x : " + (int)(vo.getX()/20) + "/ draw y : " + (int)vo.getY()/20);
		return "view";
	}
}
