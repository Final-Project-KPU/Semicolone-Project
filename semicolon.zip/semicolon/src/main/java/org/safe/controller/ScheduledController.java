package org.safe.controller;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/schedule")
public class ScheduledController {
	
	private static final Logger logger = LoggerFactory.getLogger(ScheduledController.class);
	
	//@Scheduled(fixedRate = 5000)
	@RequestMapping(value = "/scheduled", method = RequestMethod.GET)
	public void scheduled() throws Exception{
		Date now = new Date();
		logger.info(now.toString());
	}
}
