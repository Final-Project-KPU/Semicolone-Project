package org.safe.service;

import java.util.List;

import org.safe.domain.Criteria;
import org.safe.domain.DistapVO;
import org.safe.domain.PositVO;

public interface DistapService {
	public PositVO distapList(int band_id) throws Exception;
	public PositVO calculate(List<DistapVO> fl, int num) throws Exception;
	public Criteria getCriteria() throws Exception;
} 
