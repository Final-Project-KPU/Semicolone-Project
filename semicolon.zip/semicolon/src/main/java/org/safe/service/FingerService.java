package org.safe.service;

import java.util.List;

import org.safe.domain.FingerVO;

public interface FingerService {
	public List<FingerVO> fingerList() throws Exception;
} 
