package org.safe.service;

import java.util.List;

import org.safe.domain.FingerVO;
import org.safe.domain.PositVO;

public interface CalculationService {
	
	public void fingerList() throws Exception;
	public PositVO calculate(List<FingerVO> fl) throws Exception;
}
