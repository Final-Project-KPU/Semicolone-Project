package org.safe.service;

import org.safe.domain.PositVO;

public interface PositService {
	
	public void insertPosit(PositVO p)throws Exception;
	
	public PositVO inquire(int band_id)throws Exception;
	
}
