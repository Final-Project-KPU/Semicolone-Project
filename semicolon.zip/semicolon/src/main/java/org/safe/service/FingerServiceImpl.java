package org.safe.service;

import java.util.List;

import javax.inject.Inject;

import org.safe.domain.FingerVO;
import org.safe.persistence.FingerDAO;
import org.springframework.stereotype.Service;

@Service
public class FingerServiceImpl implements FingerService {
	
	@Inject
	FingerDAO dao;
	
	@Override
	public List<FingerVO> fingerList() throws Exception{
		// TODO Auto-generated method stub
		return dao.fingerList();
	}
}
