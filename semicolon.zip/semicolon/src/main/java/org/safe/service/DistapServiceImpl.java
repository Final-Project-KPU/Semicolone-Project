package org.safe.service;

import java.util.List;

import javax.inject.Inject;

import org.safe.domain.Criteria;
import org.safe.domain.DistapVO;
import org.safe.domain.PositVO;
import org.safe.domain.Triangulation;
import org.safe.persistence.DistapDAO;
import org.springframework.stereotype.Service;

@Service
public class DistapServiceImpl implements DistapService {
	
	@Inject
	DistapDAO dao;
	
	@Override
	public PositVO distapList(int band_id) throws Exception{
		// TODO Auto-generated method stub
		
		return calculate(dao.distapList(band_id), band_id);
	}
	
	@Override
	public PositVO calculate(List<DistapVO> dl, int band_id) throws Exception{
		// TODO Auto-generated method stub
		
		PositVO p = new PositVO();
		int[] dist= new int[3];
		int i = 0 ;
		
		for(DistapVO d : dl) {
			dist[i] = d.getDist();
			i++;
		}
		
		Triangulation tr = new Triangulation();
		tr.calculate(dl.get(0).getX(), dl.get(0).getY(), 
				dl.get(1).getX(), dl.get(1).getY(), 
				dl.get(2).getX(), dl.get(2).getY(), dist);
		
		p.setBand_id(band_id);
		p.setX(tr.getX());
		p.setY(tr.getY());
		p.setSign();
		
		return p;
	}
	
	@Override
	public Criteria getCriteria() throws Exception{
		return dao.getCriteria();
	}
}
