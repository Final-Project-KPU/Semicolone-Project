package org.safe.service;

import java.util.List;

import javax.inject.Inject;

import org.safe.domain.FingerVO;
import org.safe.domain.PositVO;
import org.safe.domain.Triangulation;
import org.safe.persistence.FingerDAO;
import org.springframework.stereotype.Service;

@Service
public class CalculationServiceImpl implements CalculationService {
	
	@Inject
	FingerDAO fingerDao;
	
	@Override
	public void fingerList() throws Exception{
		// TODO Auto-generated method stub
		
	}

	@Override
	public PositVO calculate(List<FingerVO> fl) throws Exception{
		// TODO Auto-generated method stub
		
		PositVO p = new PositVO();
		double[] dis= new double[3];
		int i = 0 ;
		
		for(FingerVO f : fl) {
			dis[i] = f.getDis();
			i++;
		}
		
		Triangulation tr = new Triangulation();
		tr.calculate(fl.get(0).getX(), fl.get(0).getY(), 
				fl.get(1).getX(), fl.get(1).getY(), 
				fl.get(2).getX(), fl.get(2).getY(), dis);
		
		p.setX(tr.getX());
		p.setY(tr.getY());
		
		return p;
	}
}
