package org.safe.service;

import javax.inject.Inject;

import org.safe.domain.PositVO;
import org.safe.persistence.PositDAO;
import org.springframework.stereotype.Service;

@Service
public class PositServiceImpl implements PositService {
	
	@Inject
	PositDAO Dao;
	
	public PositVO inquire() throws Exception{
		return Dao.inquire();
	}
	
	public void insertPosit(PositVO p)throws Exception{
		Dao.insert(p);
	}
}
