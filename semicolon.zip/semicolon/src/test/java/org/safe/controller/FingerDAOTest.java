package org.safe.controller;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.safe.domain.FingerVO;
import org.safe.persistence.FingerDAO;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"file:src/main/webapp/WEB-INF/spring/*.xml"})

public class FingerDAOTest {
	@Inject
	private FingerDAO dao;
	
	
	private static Logger logger = LoggerFactory.getLogger(FingerDAOTest.class);
	
	@Test
	  public void testGet() throws Exception {
		List<FingerVO> fl = new ArrayList<FingerVO>(); 
	    fl = dao.fingerList();
	    logger.info(fl.toString());
	  }
}
