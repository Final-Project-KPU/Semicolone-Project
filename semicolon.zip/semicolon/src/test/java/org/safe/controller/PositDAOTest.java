package org.safe.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.test.context.ContextConfiguration;
import org.safe.domain.PositVO;
import org.safe.persistence.PositDAO;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"file:src/main/webapp/WEB-INF/spring/*.xml"})

public class PositDAOTest{
	@Inject
	private PositDAO dao;
	
	private static Logger logger = LoggerFactory.getLogger(PositDAOTest.class);
	
	 private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
	 
	  //@Test
	  public void testInsert() throws Exception {

	    PositVO posit = new PositVO();
	    posit.setX(1);
	    posit.setY(1);
	    posit.setSign();
	    dao.insert(posit);
	  }
	  
	  //@Test
	  @Scheduled(fixedRate = 10)
	    public void reportCurrentTime() {
	        logger.info("The time is now {}", dateFormat.format(new Date()));
	    }
	  
	  @Test
	  public void testSelect() throws Exception{
		  PositVO posit = new PositVO();
		  posit = dao.inquire();
		  logger.info(posit.toString());
	  }
}
