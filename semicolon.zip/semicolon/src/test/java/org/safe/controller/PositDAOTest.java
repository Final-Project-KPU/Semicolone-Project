package org.safe.controller;



import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.safe.domain.PositVO;
import org.safe.persistence.PositDAO;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"file:src/main/webapp/WEB-INF/spring/*.xml"})

public class PositDAOTest{
	@Inject
	private PositDAO dao;
	
	private static Logger logger = LoggerFactory.getLogger(PositDAOTest.class);
	
	 
	  //@Test
	  public void testInsert() throws Exception {

	    PositVO posit = new PositVO();
	    posit.setBand_id(1);
	    posit.setX(1);
	    posit.setY(1);
	    posit.setSign();
	    dao.insert(posit);
	  }
	  
	  
	  @Test
	  public void testSelect() throws Exception{
		  PositVO posit = new PositVO();
		  posit = dao.inquire(1);
		  logger.info(posit.toString());
	  }
}
