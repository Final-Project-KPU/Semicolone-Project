package org.safe.controller;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.safe.domain.Criteria;
import org.safe.domain.DistapVO;
import org.safe.persistence.DistapDAO;
import org.safe.service.DistapService;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations= {"file:src/main/webapp/WEB-INF/spring/*.xml"})

public class DistapDAOTest {
	@Inject
	private DistapDAO dao;
	
	@Inject
	private DistapService ser;
	
	
	private static Logger logger = LoggerFactory.getLogger(DistapDAOTest.class);
	
	@Test
	  public void testGet() throws Exception {
		List<DistapVO> fl = new ArrayList<DistapVO>(); 
	    fl = dao.distapList(2);
	    logger.info(fl.toString());
	  }
	
	@Test
	public void getCriteria() throws Exception{
		
		Criteria cr = new Criteria();
		cr = dao.getCriteria();
		logger.info(cr.toString());
	}
	
}
